import { useState, useEffect, useRef, useCallback } from "react";

// ─────────────────────────────────────────────────────────────────────────────
// DATA
// ─────────────────────────────────────────────────────────────────────────────

const SECTIONS = [
  {
    id: "S1", label: "Section 1", color: "#3B5BDB",
    title: "Laying the Foundation",
    subtitle: "How Obinna Funded and Structured Novelle Café",
    narrative: `Mr. Obinna Ikenna had always dreamed of running a business that blended comfort, convenience, and community. After ten years in the banking industry, he resigned in late 2022 and began planning the January 2023 launch of Novelle Café & Business Services Ltd — a hybrid business combining a cosy café with on-site printing, scanning, typing, and virtual support services.

On January 5, 2023, he registered the company as a limited liability company with the Corporate Affairs Commission, choosing this structure to separate his personal finances from the business.

To fund the startup, Obinna contributed ₦3,000,000 of his personal savings as capital. His cousin Ngozi offered an interest-free loan of ₦2,000,000 repayable over 12 months. With ₦5,000,000 in total funds, he signed a one-year lease on a two-room space in Surulere for ₦1,200,000 paid upfront, then purchased café equipment and furnishings worth ₦800,000 and business equipment (printers, computers, photocopier) costing ₦1,000,000.

As at January 31, 2023:
• Cash at bank: ₦2,000,000
• Equipment and furnishings: ₦1,800,000
• Prepaid rent (for one year): ₦1,200,000
• Loan from Ngozi: ₦2,000,000
• Obinna's capital: ₦3,000,000

The books balanced: ₦5,000,000 in assets = ₦2,000,000 in liabilities + ₦3,000,000 in equity.`,
  },
  {
    id: "S2", label: "Section 2", color: "#0CA678",
    title: "Every Naira Has Two Sides",
    subtitle: "Obinna Learns to Record Transactions",
    narrative: `The first week of February arrived and with it the grand opening. Obinna began formally recording transactions under the double-entry system — every transaction recorded in at least two accounts, debits always equalling credits.

Key February transactions included:
• Feb 1 — Cash sale: cappuccino & croissant ₦3,500 → Dr Cash / Cr Sales Revenue
• Feb 1 — Printing & scanning services ₦5,000 → Dr Cash / Cr Business Services Revenue
• Feb 4 — Café supplies (coffee beans, milk, sugar, cups) ₦120,000 → Dr Inventory / Cr Cash
• Feb 6 — Staff salaries ₦80,000 × 2 = ₦160,000 → Dr Salaries Expense / Cr Cash
• Feb 14 — Invoice to consulting firm for document services ₦25,000 → Dr Accounts Receivable / Cr Business Services Revenue
• Feb 20 — Internet subscription renewal ₦35,000 → Dr Internet Expense / Cr Cash

From the Case Questions (March 2023 activity):
• Paid ₦80,000 for marketing flyers
• Bought consumables on credit ₦45,000
• Received ₦250,000 for a training session
• Paid ₦20,000 to staff for catering support
• Customer pays ₦120,000 previously owed

Trial Balance extract (31 March 2023):
Cash ₦1,500,000 | AR ₦120,000 | Equipment ₦1,800,000 | Payables ₦45,000 | Loan ₦2,000,000 | Capital ₦3,000,000`,
  },
  {
    id: "S3", label: "Section 3", color: "#E67700",
    title: "Posting to Ledgers & Balancing the Books",
    subtitle: "Trial Balance and Ledger Classification",
    narrative: `The end of February arrived. The accountant explained that it was time to post journal entries into the General Ledger — individual T-accounts collecting all transactions by account throughout the month.

After posting, they prepared a Trial Balance — a list of all accounts and balances. Total debits equalled total credits: ₦782,500 each. The accountant cautioned Obinna: "Balancing doesn't mean there are no errors — it just means debits equal credits. Entries posted to the wrong account or omitted entirely would not be caught."

Ledger balances as at 31 October 2023:
• Office Furniture ₦500,000
• Accounts Payable ₦60,000
• Owner's Capital ₦3,000,000
• Catering Revenue ₦350,000
• Salaries Expense ₦100,000

Trial Balance (Oct 2023):
Cash ₦1,000,000 · AR ₦150,000 · Equipment ₦1,200,000 · Marketing Expense ₦50,000 · AP ₦80,000 · Sales Revenue ₦1,500,000 · Owner's Capital ₦1,500,000`,
  },
  {
    id: "S4", label: "Section 4", color: "#9C36B5",
    title: "Tying Up Loose Ends",
    subtitle: "Year-End Adjustments at Novelle Café",
    narrative: `It is the last day of 2023. Obinna's accounting assistant has generated the trial balance and identifies five year-end adjustments required under accrual accounting:

Adjustment 1 — Prepaid Rent (Accruals Concept)
Novelle Café paid ₦3,600,000 for a 12-month lease on July 1, 2023. Only 6 months used by Dec 31. Remaining 6 months = ₦1,800,000 must be recognised as Prepaid Rent (asset) for Jan–Jun 2024.

Adjustment 2 — Accrued Salaries (Matching Concept)
Staff are paid on the 5th of the following month. December salaries of ₦500,000 are unpaid at Dec 31 but have been earned — must be recognised as an expense and accrued liability.

Adjustment 3 — Unearned Revenue (Accruals Concept)
On Dec 20, 2023, a client paid ₦600,000 in advance for training to be held in January 2024. Revenue not yet earned — must be recognised as a liability (Deferred Revenue / Unearned Revenue).

Adjustment 4 — Depreciation (Matching & Prudence Concept)
Equipment purchased July 2023 for ₦3,000,000 with 5-year life, no residual value. Annual depreciation = ₦600,000. Only 6 months in 2023 = ₦300,000 to be charged.

Adjustment 5 — Accrued Revenue (Realization Concept)
Business services worth ₦150,000 provided on Dec 29 but not yet invoiced. Revenue earned — must be recognized in 2023 as Accrued Revenue (asset) and Service Revenue (income).`,
  },
  {
    id: "S5", label: "Module 2–3", color: "#C92A2A",
    title: "Key Accounting Concepts & The Accounting Equation",
    subtitle: "Access Bank ELTP — Basic Accounting Practice Questions",
    narrative: `MODULE 2: KEY ACCOUNTING CONCEPTS

Accruals Concept: Revenue and expenses are recognised when earned/incurred, not when cash is received/paid. This affects the Trial Balance (accrued/prepaid items appear), the Income Statement (correct period matching), and the Balance Sheet (prepayments, accruals shown as assets/liabilities).

Materiality: An item is material if its omission or misstatement would influence economic decisions. Immaterial items may be expensed immediately rather than capitalised (e.g. a ₦500 stapler may be expensed even though technically a non-current asset).

MODULE 3: THE ACCOUNTING EQUATION

Assets = Liabilities + Equity

Assets: Resources controlled by the entity from which future economic benefits are expected (cash, inventory, equipment, receivables).
Liabilities: Present obligations from past events, settlement expected to result in outflow of resources (loans, payables, accruals).
Equity: Residual interest in assets after deducting liabilities (capital + retained profits).

The Dual Aspect Concept: Every transaction has two aspects — giving and receiving. Recording both aspects maintains the accounting equation.

Revenues increase equity (profits retained in the business). Expenses decrease equity (consuming resources reduces the owner's claim).`,
  },
  {
    id: "S6", label: "Module 5–6", color: "#1864AB",
    title: "Double Entry & The Accounting Cycle",
    subtitle: "Journal Entries, Ledgers, Trial Balance",
    narrative: `MODULE 5: DOUBLE ENTRY ACCOUNTING

Rules:
• Debit: Increases in Assets and Expenses; Decreases in Liabilities, Equity, and Income
• Credit: Increases in Liabilities, Equity, and Income; Decreases in Assets and Expenses

Every transaction must have at least one debit and one credit entry, and total debits must equal total credits.

MODULE 6: THE ACCOUNTING CYCLE (Journal Entries)

Journal entries record the initial effect of transactions. Key types include:
• Purchases on credit: Dr Purchases/Asset / Cr Accounts Payable
• Cash sales: Dr Cash / Cr Sales Revenue
• Bad debts written off: Dr Bad Debt Expense / Cr Accounts Receivable
• Drawings by owner: Dr Drawings / Cr Inventory/Cash
• Returns outward: Dr Accounts Payable / Cr Purchases Returns
• Asset purchased on credit: Dr Asset / Cr Accounts Payable`,
  },
  {
    id: "S7", label: "Module 7", color: "#2B8A3E",
    title: "Bank Reconciliation",
    subtitle: "Reconciling Cash Book to Bank Statement",
    narrative: `MODULE 7: BANK RECONCILIATION STATEMENT

The cash book balance and bank statement balance will often differ due to:
1. Outstanding/unpresented cheques — issued but not yet cleared at bank
2. Deposits in transit — recorded in cash book, not yet credited by bank
3. Bank charges/interest — debited by bank, not yet in cash book
4. Direct credits (RTGS, dividends) — credited by bank, not in cash book
5. Direct debits (standing orders) — debited by bank, not in cash book
6. Returned/dishonoured cheques — bounced, reversed by bank
7. Errors — in either the cash book or bank statement

RECONCILIATION APPROACH:
Start with the Bank Statement balance:
+ Deposits in transit (not yet credited)
− Outstanding cheques (not yet presented)
= Adjusted Bank Balance

Adjust the Cash Book:
+ Direct credits not in cash book (dividends, transfers)
− Bank charges, standing orders, direct debits
± Correct errors in cash book
= Adjusted Cash Book Balance

Both adjusted balances should agree.`,
  },
];

const QUESTIONS = [
  // ── SECTION 1 ──────────────────────────────────────────────────────────────
  {
    id: 1, sec: "S1", num: "Q1", difficulty: "Medium",
    title: "Accounting Equation — Transaction Impact",
    text: "Using the accounting equation (Assets = Liabilities + Owner's Equity), show the impact of each of Novelle Café's four January 2023 transactions. For each, state the accounts affected, the direction of change, and confirm the equation remains balanced.",
    marks: "Structured Calculation — 4 Marks",
    hint: "Remember: transactions (c) and (d) are asset swaps — they do not change total assets.",
    answer: `a) Dr Bank ₦3,000,000 / Cr Capital ₦3,000,000
   Assets +₦3,000,000 | Liabilities — | Equity +₦3,000,000 ✓

b) Dr Bank ₦2,000,000 / Cr Loan (Ngozi) ₦2,000,000
   Assets +₦2,000,000 | Liabilities +₦2,000,000 | Equity — ✓

c) Dr Prepaid Rent ₦1,200,000 / Cr Bank ₦1,200,000
   Assets: Cash −₦1,200,000 + Prepaid Rent +₦1,200,000 = NET 0
   Liabilities — | Equity — ✓ (Asset swap)

d) Dr Equipment ₦1,800,000 / Cr Bank ₦1,800,000
   Assets: Cash −₦1,800,000 + Equipment +₦1,800,000 = NET 0
   Liabilities — | Equity — ✓ (Asset swap)

NET POSITION: Total Assets +₦5,000,000 | Liabilities +₦2,000,000 | Equity +₦3,000,000`,
    explain: "Transactions (a) and (b) change both sides of the equation. Transactions (c) and (d) are asset swaps — one asset falls, another rises by the same amount, so total assets and the other sides of the equation are unchanged. The equation must balance after every single transaction.",
  },
  {
    id: 2, sec: "S1", num: "Q2", difficulty: "Medium",
    title: "Statement of Financial Position — 31 January 2023",
    text: "Prepare Novelle Café's Statement of Financial Position as at 31 January 2023, using the accounting equation format. Show all assets, liabilities, and owner's equity clearly, and verify the equation balances.",
    marks: "Structured Calculation — 4 Marks",
    hint: "Opening cash = ₦3m + ₦2m = ₦5m. Then subtract rent paid and equipment purchased.",
    answer: `NOVELLE CAFÉ — Statement of Financial Position as at 31 January 2023

NON-CURRENT ASSETS
  Equipment & Furnishings          ₦1,800,000

CURRENT ASSETS
  Prepaid Rent                     ₦1,200,000
  Cash at Bank                     ₦2,000,000
  Total Current Assets             ₦3,200,000

TOTAL ASSETS                       ₦5,000,000

NON-CURRENT LIABILITIES
  Loan from Ngozi                  ₦2,000,000

TOTAL LIABILITIES                  ₦2,000,000

OWNER'S EQUITY
  Obinna's Capital                 ₦3,000,000

TOTAL LIABILITIES + EQUITY        ₦5,000,000 ✓

Working — Cash: ₦3,000,000 + ₦2,000,000 − ₦1,200,000 − ₦1,800,000 = ₦2,000,000`,
    explain: "Cash = inflows (₦3m capital + ₦2m loan) minus outflows (₦1.2m rent + ₦1.8m equipment) = ₦2m. Rent paid upfront creates a Prepaid Rent asset (benefit not yet consumed). Equipment is a non-current asset. The loan is classified as non-current if repayable in > 1 year; here it is repayable over 12 months so borderline — many would classify as current.",
  },
  {
    id: 3, sec: "S1", num: "Q3", difficulty: "Hard",
    title: "Asset vs Prepaid Expense — Conceptual Application",
    text: "Critically explain why Novelle Café's ₦1,800,000 equipment purchase is classified as a non-current asset while the ₦1,200,000 rent payment is classified as a prepaid expense. Reference at least TWO accounting concepts in your answer.",
    marks: "Short Answer — 4 Marks",
    hint: "Think about the matching concept, going concern, and the distinction between capital and revenue expenditure.",
    answer: `Equipment (₦1,800,000) — Non-Current Asset:
• Capital Expenditure: Expenditure that generates economic benefits across multiple accounting periods. Equipment will be used for several years → it must be capitalised on the Balance Sheet, not expensed immediately.
• Matching Concept: The cost is matched to the periods it benefits through depreciation. Each year, a portion of ₦1,800,000 is charged as Depreciation Expense.
• Going Concern: Assumes the business will continue operating, so long-lived assets are recognised and depreciated rather than written off immediately.

Prepaid Rent (₦1,200,000) — Current Asset (Prepaid Expense):
• Revenue Expenditure: Expenditure whose benefit is consumed within one accounting period (one year).
• Accruals/Matching Concept: Although ₦1,200,000 was paid upfront, only ₦100,000/month should be recognised as Rent Expense. The remaining unused portion = a current asset (Prepaid Rent) representing a future economic benefit.
• Each month: Dr Rent Expense ₦100,000 / Cr Prepaid Rent ₦100,000

Key distinction: Duration of benefit. >1 year → non-current asset. ≤1 year → prepaid/current asset or expense.`,
    explain: "This tests the capital vs revenue expenditure distinction, the matching (accruals) concept, and going concern. Many students confuse 'paid in cash' with 'expense' — the timing of payment is irrelevant under accrual accounting. What matters is when the economic benefit is consumed.",
  },
  // ── SECTION 2 ──────────────────────────────────────────────────────────────
  {
    id: 4, sec: "S2", num: "Q4", difficulty: "Medium",
    title: "Double Entry — Identify Debit and Credit Accounts",
    text: "For each of the five March 2023 transactions at Novelle Café, identify the TWO accounts affected and state clearly whether each is DEBITED or CREDITED. Also state the account type (Asset / Liability / Equity / Income / Expense) for each account.",
    marks: "Double Entry — 10 Marks",
    hint: "Apply the rules: Assets and Expenses increase with a Debit. Liabilities, Equity, and Income increase with a Credit.",
    answer: `a) Paid ₦80,000 for marketing flyers:
   Dr Marketing Expense ₦80,000 [Expense ↑]
   Cr Cash ₦80,000 [Asset ↓]

b) Bought consumables on credit ₦45,000:
   Dr Office Consumables Expense ₦45,000 [Expense ↑]
   Cr Accounts Payable ₦45,000 [Liability ↑]

c) Received ₦250,000 for training session:
   Dr Cash ₦250,000 [Asset ↑]
   Cr Training Income ₦250,000 [Income ↑]

d) Paid ₦20,000 to staff for catering support:
   Dr Catering Expense ₦20,000 [Expense ↑]
   Cr Cash ₦20,000 [Asset ↓]

e) Customer pays ₦120,000 previously owed:
   Dr Cash ₦120,000 [Asset ↑]
   Cr Accounts Receivable ₦120,000 [Asset ↓]
   NOTE: (e) is an Asset-for-Asset swap — total assets unchanged.`,
    explain: "Transaction (e) is a common trap: both accounts are assets. The receipt of cash settles a receivable — one asset rises, another falls. Total assets, liabilities, and equity are all unchanged. Transactions (a) and (d) reduce equity indirectly via expenses; (c) increases equity via income.",
  },
  {
    id: 5, sec: "S2", num: "Q5", difficulty: "Medium",
    title: "Account Classification from Journal Entries",
    text: "Classify both the debit and credit accounts in each journal entry below as Asset, Liability, Equity, Income, or Expense. Then state the net effect on the accounting equation for each entry.\n\na) Dr Cash ₦250,000 / Cr Training Income ₦250,000\nb) Dr Catering Expense ₦20,000 / Cr Cash ₦20,000\nc) Dr Office Consumables ₦45,000 / Cr Payables ₦45,000\nd) Dr Cash ₦120,000 / Cr Accounts Receivable ₦120,000",
    marks: "Classification — 8 Marks",
    hint: "For each entry, also think about whether it increases or decreases the owner's equity indirectly.",
    answer: `a) Dr Cash [Asset ↑] / Cr Training Income [Income ↑]
   Effect: Assets +₦250,000 | Equity +₦250,000 (via income → retained profits)

b) Dr Catering Expense [Expense ↑] / Cr Cash [Asset ↓]
   Effect: Assets −₦20,000 | Equity −₦20,000 (via expense → reduces profits)

c) Dr Office Consumables [Expense ↑] / Cr Payables [Liability ↑]
   Effect: Liabilities +₦45,000 | Equity −₦45,000 (expense recognised)
   NOTE: Assets unchanged — bought on credit, not yet paid in cash

d) Dr Cash [Asset ↑] / Cr Accounts Receivable [Asset ↓]
   Effect: NET ZERO — both sides are assets. Assets unchanged, L unchanged, E unchanged.`,
    explain: "The key insight: Income increases equity; Expenses decrease equity — even before cash changes hands. Entry (c) creates a liability and reduces equity simultaneously with no cash movement. Entry (d) is purely an asset conversion — no equity, liability, or net asset change.",
  },
  {
    id: 6, sec: "S2", num: "Q6", difficulty: "Hard",
    title: "Trial Balance — Totals, Classification & Equity Verification",
    text: "Using Novelle Café's trial balance extract (31 March 2023) from the case study, complete the following:\na) Classify each account as Asset (Current/Non-current), Liability (Current/Non-current), or Equity\nb) Calculate Total Assets and Total Liabilities\nc) Using the accounting equation, derive the Owner's Equity and explain why it differs from the opening capital of ₦3,000,000",
    marks: "Trial Balance Analysis — 8 Marks",
    hint: "Equity = Assets − Liabilities. If equity has changed from ₦3m, it means income/expenses have occurred during the period.",
    answer: `CLASSIFICATION:
  Cash ₦1,500,000 → Current Asset
  Accounts Receivable ₦120,000 → Current Asset
  Equipment & Furnishings ₦1,800,000 → Non-Current Asset
  Payables ₦45,000 → Current Liability
  Loan from Ngozi ₦2,000,000 → Non-Current Liability
  Owner's Capital ₦3,000,000 → Equity

Total Assets = ₦1,500,000 + ₦120,000 + ₦1,800,000 = ₦3,420,000
Total Liabilities = ₦45,000 + ₦2,000,000 = ₦2,045,000

Derived Equity = ₦3,420,000 − ₦2,045,000 = ₦1,375,000

WHY EQUITY ≠ ₦3,000,000:
The business has incurred expenses (marketing, catering, salaries etc.) during the period Jan–Mar 2023. These reduce equity. The trial balance reflects the closing position after expenses have been charged. Equity = Opening Capital + Net Profit − Drawings. If no drawings, then ₦1,375,000 = ₦3,000,000 + Net profit for the period → net loss of ₦1,625,000 in Q1. (This reflects heavy startup expenditure.)`,
    explain: "This is a critical test: students must realise the trial balance does NOT show 'Owner's Capital' as the current equity — it shows the opening capital contribution. Actual current equity must be derived as Assets − Liabilities. The difference from opening capital is the net income/(loss) for the period.",
  },
  // ── SECTION 3 ──────────────────────────────────────────────────────────────
  {
    id: 7, sec: "S3", num: "Q7", difficulty: "Easy",
    title: "Ledger Account Classification",
    text: "Classify each of the five October 2023 ledger balances as Asset, Liability, Equity, Income, or Expense. For each, also state: (i) whether it appears on the Balance Sheet or Income Statement, and (ii) whether it is a permanent or temporary account.",
    marks: "Classification — 5 Marks",
    hint: "Temporary accounts (income and expenses) are closed to retained earnings at year-end. Permanent accounts carry forward.",
    answer: `Office Furniture ₦500,000
  → Asset (Non-current) | Balance Sheet | PERMANENT

Accounts Payable ₦60,000
  → Liability (Current) | Balance Sheet | PERMANENT

Owner's Capital ₦3,000,000
  → Equity | Balance Sheet | PERMANENT

Catering Revenue ₦350,000
  → Income | Income Statement | TEMPORARY (closed to P&L / Retained Earnings at year-end)

Salaries Expense ₦100,000
  → Expense | Income Statement | TEMPORARY (closed to P&L / Retained Earnings at year-end)`,
    explain: "The permanent vs temporary distinction is crucial. Assets, liabilities, and equity balances carry forward to the next period. Income and expense accounts start at zero each period and are closed to equity (retained earnings/profit & loss account) at year-end. This is how the Balance Sheet reflects cumulative wealth while the Income Statement reflects a single period's performance.",
  },
  {
    id: 8, sec: "S3", num: "Q8", difficulty: "Hard",
    title: "Trial Balance — Verification & Error Analysis",
    text: "Using the October 2023 trial balance data:\na) Calculate total debits and total credits\nb) State whether the trial balance balances\nc) If it does not balance, state the exact difference and identify THREE possible causes of the imbalance\nd) Name TWO types of errors that a balanced trial balance would STILL fail to detect",
    marks: "Trial Balance Check — 8 Marks",
    hint: "A balanced trial balance does NOT mean the accounts are error-free. Think about compensating errors and errors of principle.",
    answer: `Total Debits = ₦1,000,000 + ₦150,000 + ₦1,200,000 + ₦50,000 = ₦2,400,000
Total Credits = ₦80,000 + ₦1,500,000 + ₦1,500,000 = ₦3,080,000

The trial balance does NOT balance.
Difference = ₦3,080,000 − ₦2,400,000 = ₦680,000 (debits short)

THREE POSSIBLE CAUSES:
1. A debit entry of ₦680,000 was omitted entirely (e.g. an asset purchase or expense not posted)
2. A ₦340,000 debit was posted twice to the credit side (₦340,000 × 2 = ₦680,000 imbalance)
3. A transposition error: e.g. ₦680,000 written as ₦860,000 on the debit side → short by ₦180,000 (not this), OR a ₦680,000 figure entered as ₦0 on the debit side

TWO ERRORS NOT DETECTED BY A BALANCED TRIAL BALANCE:
1. Error of Commission: Transaction posted to the correct type of account but wrong account (e.g. ₦50,000 electricity paid debited to Water Rates instead of Electricity — both are expenses, debits and credits still balance)
2. Compensating Errors: Two separate errors that cancel each other out (e.g. Sales understated by ₦10,000 AND Purchases overstated by ₦10,000 — debits and credits still balance)
Others: Error of Omission (entire transaction omitted), Error of Principle (wrong account category), Complete Reversal of Entry.`,
    explain: "A balanced trial balance is a necessary but not sufficient condition for accurate records. The six types of errors not detected: omission, commission, principle, original entry, reversal, and compensating errors. This is a commonly tested concept at professional level.",
  },
  {
    id: 9, sec: "S3", num: "Q9", difficulty: "Hard",
    title: "Adjusting Entry — Deferred Revenue & Accruals Concept",
    text: "A corporate client paid Novelle Café ₦120,000 in advance for future training services. At month-end, only ₦40,000 worth of services has been rendered.\n\na) Record the INITIAL journal entry when cash was received\nb) Record the ADJUSTING journal entry at month-end\nc) Classify all four accounts involved by type and show their balance sheet treatment\nd) Which accounting concept requires this adjustment? Explain it.",
    marks: "Adjusting Entries — 6 Marks",
    hint: "When cash is received BEFORE services are delivered, the business owes the service — it is a liability until earned.",
    answer: `a) INITIAL ENTRY (when ₦120,000 cash received):
   Dr Cash ₦120,000 [Asset ↑]
   Cr Deferred Revenue ₦120,000 [Liability ↑]
   (The business has not yet earned this money — it owes a service)

b) MONTH-END ADJUSTING ENTRY (₦40,000 now earned):
   Dr Deferred Revenue ₦40,000 [Liability ↓]
   Cr Service Revenue ₦40,000 [Income ↑]

c) ACCOUNT CLASSIFICATIONS:
   Cash → Asset (Current) — Balance Sheet
   Deferred Revenue → Liability (Current) — Balance Sheet — remaining ₦80,000 stays here until earned
   Service Revenue → Income — Income Statement — only ₦40,000 recognised this period
   Deferred Revenue (after adjustment) = ₦80,000 liability

d) ACCOUNTING CONCEPT: The Accruals (Matching) Concept
   Revenue must be recognised in the period in which it is EARNED, not when cash is received. Until the service is performed, the business has an obligation to the client — a liability. As services are performed, the liability is extinguished and income is recognised. This prevents overstating income in early periods.`,
    explain: "This tests the accruals concept and the correct treatment of unearned revenue. A very common exam trap: students often credit Revenue immediately when cash is received. The correct treatment: credit Deferred Revenue (liability) first, then recognise revenue as services are performed. The ₦80,000 balance remains a liability until the remaining services are delivered.",
  },
  // ── SECTION 4 ──────────────────────────────────────────────────────────────
  {
    id: 10, sec: "S4", num: "Q10", difficulty: "Hard",
    title: "Year-End Adjustments — All Five Entries",
    text: "Record ALL FIVE year-end adjusting journal entries for Novelle Café as at 31 December 2023. For each entry, state the accounting concept that requires it and the effect on the financial statements.",
    marks: "Adjusting Entries — 10 Marks",
    hint: "Depreciation: annual = Cost ÷ Useful life. Only 6 months in 2023, so charge 6/12 of annual depreciation.",
    answer: `1. PREPAID RENT (Accruals Concept)
   Lease ₦3,600,000 for 12 months from July 1, 2023.
   Used: 6 months (Jul–Dec 2023) = ₦1,800,000 → Rent Expense
   Unused: 6 months (Jan–Jun 2024) = ₦1,800,000 → Prepaid Rent (Asset)
   Entry: Dr Rent Expense ₦1,800,000 / Cr Prepaid Rent ₦1,800,000
   Effect: Expense ↑ on I/S; Current Asset ↓ on B/S

2. ACCRUED SALARIES (Matching Concept)
   December salaries ₦500,000 earned but not yet paid.
   Entry: Dr Salaries Expense ₦500,000 / Cr Accrued Salaries ₦500,000
   Effect: Expense ↑ on I/S; Current Liability ↑ on B/S

3. UNEARNED REVENUE (Accruals Concept)
   ₦600,000 received Dec 20 for January 2024 training.
   (Assuming initial entry was Dr Cash / Cr Revenue — must reverse):
   Entry: Dr Service Revenue ₦600,000 / Cr Deferred Revenue ₦600,000
   Effect: Income ↓ on I/S; Current Liability ↑ on B/S

4. DEPRECIATION (Matching & Prudence Concepts)
   Equipment ₦3,000,000, 5-year life, no residual.
   Annual depreciation = ₦3,000,000 ÷ 5 = ₦600,000
   6 months charge (Jul–Dec 2023) = ₦600,000 × 6/12 = ₦300,000
   Entry: Dr Depreciation Expense ₦300,000 / Cr Accumulated Depreciation ₦300,000
   Effect: Expense ↑ on I/S; Non-current Asset (net) ↓ on B/S

5. ACCRUED REVENUE (Realization/Accruals Concept)
   Services ₦150,000 provided Dec 29 but not yet invoiced.
   Entry: Dr Accrued Revenue ₦150,000 / Cr Service Revenue ₦150,000
   Effect: Income ↑ on I/S; Current Asset ↑ on B/S`,
    explain: "Year-end adjustments are required under the accruals concept to ensure income and expenses are matched to the correct accounting period regardless of cash flows. Note: Depreciation always uses Accumulated Depreciation (a contra-asset) on the credit side — never credit the asset directly (under cost model). Unearned revenue is a liability, not income, until earned.",
  },
  {
    id: 11, sec: "S4", num: "Q11", difficulty: "Hard",
    title: "Depreciation — Calculation & Concepts",
    text: "Novelle Café purchased equipment for ₦3,000,000 in July 2023 with a 5-year useful life and no residual value. Using the straight-line method:\na) Calculate annual and monthly depreciation\nb) Show the journal entry for the 2023 depreciation charge\nc) Show how the equipment appears on the Balance Sheet at 31 December 2023\nd) Explain why Accumulated Depreciation is used rather than crediting the asset account directly\ne) What would change if a residual value of ₦300,000 had been assumed?",
    marks: "Depreciation — 8 Marks",
    hint: "Straight-line: (Cost − Residual Value) ÷ Useful Life. Accumulated depreciation is a contra-asset account.",
    answer: `a) DEPRECIATION CALCULATION:
   Annual = (₦3,000,000 − ₦0) ÷ 5 years = ₦600,000/year
   Monthly = ₦600,000 ÷ 12 = ₦50,000/month
   2023 charge (6 months, Jul–Dec) = ₦50,000 × 6 = ₦300,000

b) JOURNAL ENTRY (31 Dec 2023):
   Dr Depreciation Expense ₦300,000
   Cr Accumulated Depreciation — Equipment ₦300,000

c) BALANCE SHEET PRESENTATION (31 Dec 2023):
   Equipment at Cost                    ₦3,000,000
   Less: Accumulated Depreciation        (₦300,000)
   NET BOOK VALUE (Carrying Amount)     ₦2,700,000

d) WHY ACCUMULATED DEPRECIATION (not direct credit to asset):
   Using a contra-asset account preserves the historical cost on the face of the Balance Sheet while also disclosing total depreciation charged to date. Users can see both original cost and wear/usage. This complies with IAS 16 (disclosure of cost, accumulated depreciation, and NBV separately). If we credited the asset directly, historical cost information would be lost.

e) WITH RESIDUAL VALUE ₦300,000:
   Depreciable amount = ₦3,000,000 − ₦300,000 = ₦2,700,000
   Annual depreciation = ₦2,700,000 ÷ 5 = ₦540,000
   2023 charge (6 months) = ₦540,000 × 6/12 = ₦270,000
   (Lower charge → higher profit → higher equity)`,
    explain: "The use of Accumulated Depreciation as a contra-asset is required under IAS 16 and best practice. It serves transparency — showing cost, total depreciation, and net book value separately. The residual value reduces the depreciable amount. These are consistently tested principles at intermediate and advanced level.",
  },
  // ── MODULE 2–3 ─────────────────────────────────────────────────────────────
  {
    id: 12, sec: "S5", num: "Q12", difficulty: "Medium",
    title: "Accruals Concept — Full Explanation & Impact",
    text: "Explain what you understand by the accruals concept, giving a concrete example. Then explain precisely how this concept affects each of the following: (i) the Trial Balance, (ii) the Statement of Profit or Loss, and (iii) the Statement of Financial Position.",
    marks: "Conceptual — 6 Marks",
    hint: "The accruals concept is also called the matching concept. Think about what happens when expenses are incurred but not yet paid, or income is earned but not yet received.",
    answer: `THE ACCRUALS CONCEPT:
Revenue and expenses are recognised in the period in which they are earned or incurred, regardless of when cash is received or paid. Also called the matching concept — expenses are matched to the revenues they help generate in the same period.

EXAMPLE: A business pays ₦120,000 insurance premium on October 1 for a 12-month policy. At year-end (December 31), only 3 months has expired. Under accruals: only ₦30,000 is an expense (3/12 × ₦120,000). The remaining ₦90,000 is a prepaid expense (asset).

IMPACT ON FINANCIAL STATEMENTS:

(i) TRIAL BALANCE:
Accruals adjustments create additional balances that appear in the adjusted trial balance:
• Accrued expenses → create a debit (expense) and a credit (liability)
• Prepaid expenses → appear as a debit (asset) reducing the expense figure
• Accrued income → appear as a debit (asset) and credit (income)
• Deferred income → appear as a debit (income) and credit (liability)

(ii) STATEMENT OF PROFIT OR LOSS:
Ensures only the correct period's income and expenses are included. Without accruals: a business could manipulate profit by simply delaying payments or accelerating receipts. With accruals: profit reflects economic reality of the period.

(iii) STATEMENT OF FINANCIAL POSITION:
Creates additional line items:
• Prepayments and accrued income → Current Assets
• Accruals and deferred income → Current Liabilities
These ensure the B/S reflects ALL obligations and rights at the reporting date.`,
    explain: "The accruals concept is one of the two fundamental accounting concepts (alongside going concern) under FRS 18 and IAS 1. Examiners expect students to connect it to all three financial statements, not just define it. The key phrase: 'when earned/incurred, not when cash moves.'",
  },
  {
    id: 13, sec: "S5", num: "Q13", difficulty: "Medium",
    title: "Materiality — Concept & Application",
    text: "Explain the concept of materiality in accounting. Give THREE specific examples of how materiality may affect the capitalisation of amounts in a balance sheet.",
    marks: "Conceptual — 4 Marks",
    hint: "Materiality is about significance relative to the size of the business. What is material for a small business may be immaterial for a large corporation.",
    answer: `MATERIALITY:
An item is material if its omission or misstatement could reasonably influence the economic decisions of users of the financial statements. Materiality depends on the size and nature of the item judged in the circumstances. (IAS 1 / Conceptual Framework)

THREE EXAMPLES IN CAPITALISATION:

1. Small tools and equipment: A large manufacturing company purchases a ₦5,000 drill bit. Technically a non-current asset (will last 3 years). However, its cost is immaterial relative to the company's total assets of ₦500 million. It is expensed immediately rather than capitalised and depreciated — saving administrative effort without misleading users.

2. Low-value office items: Novelle Café buys a ₦2,500 stapler. Rather than creating a fixed asset record, it is immediately expensed as office supplies. Immaterial relative to the business's total asset base.

3. Minor improvement to a building: A business spends ₦15,000 repainting a room. Although it could be argued this adds value (capital expenditure), if the amount is immaterial relative to the building's ₦50,000,000 cost, it may be expensed as repairs and maintenance rather than capitalised.

IMPORTANT LIMIT: Materiality cannot override faithful representation or be used to conceal fraud. It only permits simplification in treatment of genuinely insignificant items.`,
    explain: "Materiality is a pervasive concept that interacts with almost every accounting decision. The key principle: if including or excluding the item would NOT change a user's decision, it is immaterial. Thresholds vary by entity size — there is no fixed percentage. Students must demonstrate they understand materiality is relative, not absolute.",
  },
  {
    id: 14, sec: "S5", num: "Q14", difficulty: "Medium",
    title: "Accounting Equation — Fill the Gaps",
    text: "Complete the gaps in the following accounting equation table. Show your workings for each row.\n\nAssets = Liabilities + Equity\n₦24,000 = ₦2,500 + ?\n₦15,500 = ₦3,500 + ?\n₦25,000 = ? + ₦9,500\n₦19,500 = ? + ₦3,200\n? = ₦7,500 + ₦15,550\n? = ₦15,350 + ₦71,250",
    marks: "Calculation — 6 Marks",
    hint: "Equity = Assets − Liabilities. Liabilities = Assets − Equity. Assets = Liabilities + Equity.",
    answer: `Row 1: Assets ₦24,000 = Liabilities ₦2,500 + Equity ?
  Equity = ₦24,000 − ₦2,500 = ₦21,500

Row 2: Assets ₦15,500 = Liabilities ₦3,500 + Equity ?
  Equity = ₦15,500 − ₦3,500 = ₦12,000

Row 3: Assets ₦25,000 = Liabilities ? + Equity ₦9,500
  Liabilities = ₦25,000 − ₦9,500 = ₦15,500

Row 4: Assets ₦19,500 = Liabilities ? + Equity ₦3,200
  Liabilities = ₦19,500 − ₦3,200 = ₦16,300

Row 5: Assets ? = Liabilities ₦7,500 + Equity ₦15,550
  Assets = ₦7,500 + ₦15,550 = ₦23,050

Row 6: Assets ? = Liabilities ₦15,350 + Equity ₦71,250
  Assets = ₦15,350 + ₦71,250 = ₦86,600`,
    explain: "The accounting equation is the foundation of double-entry bookkeeping. It must always hold. Rearrange as needed: Equity = Assets − Liabilities; Liabilities = Assets − Equity; Assets = Liabilities + Equity.",
  },
  {
    id: 15, sec: "S5", num: "Q15", difficulty: "Hard",
    title: "Transaction Effects — Increase/Decrease/No Effect",
    text: "For each transaction below, determine the overall effect on Assets, Liabilities, and Equity/Capital. State increase (+), decrease (−), or no effect (NE), and give the amount.\n\nb) Purchased office equipment worth ₦500,000 on credit\nc) Paid the liability for the office equipment above\nd) Owners invested further ₦390,000 cash\ne) Sold goods costing ₦5m for ₦6.5m cash\nf) Drawings of ₦250,000 by the owner\ng) ₦150,000 received from a trade debtor owing ₦229,000 as full settlement\nh) Paid employees' salaries ₦150,000 cash\ni) Earned ₦105,000 on a foreign exchange transaction\nj) Company purchases land ₦1m: paid half in cash, signed a note payable for the other half",
    marks: "Analysis — 10 Marks",
    hint: "For (g), the debtor agreed to ₦150,000 as full settlement of ₦229,000 — the ₦79,000 difference is a bad debt. For (e), profit is the gain on sale.",
    answer: `b) Purchase equipment ₦500,000 on credit:
   Assets +₦500,000 | Liabilities +₦500,000 | Equity NE

c) Paid the liability from (b):
   Assets −₦500,000 (cash) | Liabilities −₦500,000 | Equity NE

d) Owners invest ₦390,000 cash:
   Assets +₦390,000 | Liabilities NE | Equity +₦390,000

e) Sold goods (cost ₦5m) for ₦6.5m cash:
   Assets +₦6,500,000 (cash) − ₦5,000,000 (inventory) = NET +₦1,500,000
   Liabilities NE | Equity +₦1,500,000 (profit on sale)

f) Drawings ₦250,000:
   Assets −₦250,000 | Liabilities NE | Equity −₦250,000

g) Received ₦150,000 from debtor (₦229,000 owed), full settlement:
   Assets: Cash +₦150,000; AR −₦229,000 = NET −₦79,000
   Liabilities NE | Equity −₦79,000 (bad debt loss of ₦79,000)

h) Paid salaries ₦150,000:
   Assets −₦150,000 | Liabilities NE | Equity −₦150,000 (expense)

i) Earned ₦105,000 on FX transaction:
   Assets +₦105,000 | Liabilities NE | Equity +₦105,000

j) Land ₦1m: ₦500,000 cash + ₦500,000 note payable:
   Assets: Land +₦1,000,000; Cash −₦500,000 = NET +₦500,000
   Liabilities +₦500,000 (note payable) | Equity NE`,
    explain: "Transaction (g) is the hardest: a debt settlement at less than face value creates a bad debt loss (₦229,000 − ₦150,000 = ₦79,000) which reduces equity. Transaction (e) must track both the cash inflow AND the removal of inventory at cost — only the profit (₦1.5m) increases equity. Transaction (j) shows an asset acquisition partly funded by debt.",
  },
  {
    id: 16, sec: "S5", num: "Q16", difficulty: "Medium",
    title: "Balance Sheet — K Webb (31 March 20X7)",
    text: "Draw up the Balance Sheet for K Webb as at 31 March 20X7 from the following data:\n\nCapital ₦15,550 | Premises ₦26,800 | Bank loan ₦15,000 | Inventory ₦450 | Cash at bank ₦240 | Accounts payable ₦160 | Equipment ₦2,800 | Accounts receivable ₦420\n\nClassify all items correctly under current/non-current assets and current/non-current liabilities.",
    marks: "Balance Sheet — 5 Marks",
    hint: "Check: Total Assets = Total Liabilities + Capital. Premises and Equipment are non-current; Inventory, Cash, AR are current.",
    answer: `K WEBB — Balance Sheet as at 31 March 20X7

NON-CURRENT ASSETS
  Premises                          ₦26,800
  Equipment                          ₦2,800
  Total Non-Current Assets          ₦29,600

CURRENT ASSETS
  Inventory                            ₦450
  Accounts Receivable                  ₦420
  Cash at Bank                         ₦240
  Total Current Assets                ₦1,110

TOTAL ASSETS                         ₦30,710

CURRENT LIABILITIES
  Accounts Payable                     ₦160

NON-CURRENT LIABILITIES
  Bank Loan                          ₦15,000

TOTAL LIABILITIES                   ₦15,160

CAPITAL/EQUITY
  Capital                           ₦15,550

TOTAL LIABILITIES + EQUITY         ₦30,710 ✓

CHECK: ₦15,160 + ₦15,550 = ₦30,710 ✓`,
    explain: "All balance sheets must balance. The key classification rules: Assets with useful life >1 year → non-current. Assets expected to be converted to cash within 1 year → current (inventory, receivables, cash). Bank loan is typically non-current unless repayable within 1 year. Accounts payable is always current.",
  },
  {
    id: 17, sec: "S5", num: "Q17", difficulty: "Hard",
    title: "Capital Calculation — Wise's New Business",
    text: "Wise is setting up a new business. Before trading, he acquired: a van for $4,500, a market stall for $2,000, and inventory for $1,500 (of which $1,000 is still owed). He borrowed $5,000 from C. Fox. He has $400 cash and $1,100 at bank. Calculate his opening capital and prepare a simple Statement of Financial Position.",
    marks: "Calculation — 5 Marks",
    hint: "Capital = Total Assets − Total Liabilities (the accounting equation rearranged).",
    answer: `STEP 1: IDENTIFY ALL ASSETS
  Van                      $4,500
  Market Stall             $2,000
  Inventory                $1,500
  Cash in hand               $400
  Cash at bank             $1,100
  TOTAL ASSETS             $9,500

STEP 2: IDENTIFY ALL LIABILITIES
  Accounts Payable (inventory) $1,000
  Loan from C. Fox          $5,000
  TOTAL LIABILITIES         $6,000

STEP 3: CALCULATE CAPITAL
  Capital = Total Assets − Total Liabilities
  Capital = $9,500 − $6,000 = $3,500

STATEMENT OF FINANCIAL POSITION:
  NON-CURRENT ASSETS: Van $4,500 + Stall $2,000 = $6,500
  CURRENT ASSETS: Inventory $1,500 + Cash $400 + Bank $1,100 = $3,000
  TOTAL ASSETS = $9,500
  
  LIABILITIES: AP $1,000 + Loan $5,000 = $6,000
  CAPITAL = $3,500
  
  TOTAL = $9,500 ✓`,
    explain: "This tests the ability to rearrange the accounting equation to find the missing figure. Capital (owner's equity) is the residual — what belongs to the owner after all liabilities are settled. Students must correctly identify all assets (including the full inventory value of $1,500, not just the $500 paid) and all liabilities (including the $1,000 still owed for inventory and the $5,000 loan).",
  },
  // ── MODULE 5–6 ─────────────────────────────────────────────────────────────
  {
    id: 18, sec: "S6", num: "Q18", difficulty: "Medium",
    title: "MCQ — Double Entry Principles",
    text: "Answer each of the following multiple-choice questions and JUSTIFY your answer:\n\n1. When a business pays off a $1,000 loan by cash, which journal entry is correct?\nA) Dr Loan Payable $1,000 / Cr Cash $1,000\nB) Cr Cash $1,000 / Cr Loan Payable $1,000\nC) Dr Loan Expense $1,000 / Cr Cash $1,000\nD) Dr Cash $1,000 / Cr Equity $1,000\n\n2. If a company sells inventory on credit for ₦1,800, what is the correct journal entry?\nA) Dr Sales Revenue ₦1,800 / Cr Inventory ₦1,800\nB) Dr Inventory ₦1,800 / Cr Sales Revenue ₦1,800\nC) Dr Sales Revenue ₦1,800 / Cr Accounts Receivable ₦1,800\nD) Dr Accounts Receivable ₦1,800 / Cr Sales Revenue ₦1,800\n\n3. What is the effect of a CREDIT entry in an account?\nA) Increases assets\nB) Increases liabilities\nC) Decreases equity\nD) Decreases revenue",
    marks: "MCQ with justification — 6 Marks",
    hint: "Remember: Debits increase assets and expenses. Credits increase liabilities, equity, and income. Paying off a loan eliminates a liability.",
    answer: `1. CORRECT ANSWER: A) Dr Loan Payable $1,000 / Cr Cash $1,000
   Justification: Paying off a loan eliminates a liability (Loan Payable decreases → Debit) and reduces an asset (Cash decreases → Credit). B is wrong (two credits). C is wrong (loans are not 'expenses'). D is wrong (equity is not involved in a loan repayment).

2. CORRECT ANSWER: D) Dr Accounts Receivable ₦1,800 / Cr Sales Revenue ₦1,800
   Justification: A credit sale creates a receivable (asset ↑ → Debit) and recognises revenue (income ↑ → Credit). The inventory is a separate cost entry (Dr Cost of Sales / Cr Inventory) — the question only asks about the SALE entry. A, B, and C all incorrectly involve Sales Revenue on the debit side.

3. CORRECT ANSWER: B) Increases liabilities
   Justification: A credit entry increases liabilities, equity, and income; and decreases assets and expenses. A credit does NOT decrease equity (it increases it) nor does it decrease revenue.`,
    explain: "These MCQs test fundamental debit/credit rules. The critical principle: the type of account determines whether a debit or credit increases or decreases it. Many students incorrectly associate 'credit' with 'good' or 'positive' — this is wrong. A credit to an asset account DECREASES it.",
  },
  {
    id: 19, sec: "S6", num: "Q19", difficulty: "Hard",
    title: "Journal Entries — XYZ Company (August 2013)",
    text: "Write up the asset, liability, and capital accounts to record the following transactions in the records of XYZ Company:\n\na) Aug 1 — Owner starts business with ₦10,000 cash\nb) Aug 2 — Van bought for ₦4,500 cash\nc) Aug 3 — Fixtures bought on credit from Shop Fitters for ₦1,250\nd) Aug 17 — Paid amount owing to Shop Fitters in cash\n\nPresent as journal entries with narrations, then show the resulting Trial Balance.",
    marks: "Ledger Accounts & Trial Balance — 8 Marks",
    hint: "After all entries, extract balances for each account and verify total debits = total credits.",
    answer: `JOURNAL ENTRIES:

Aug 1: Dr Cash ₦10,000 / Cr Capital ₦10,000
  (Owner introduces capital)

Aug 2: Dr Van ₦4,500 / Cr Cash ₦4,500
  (Purchased van for cash)

Aug 3: Dr Fixtures ₦1,250 / Cr Accounts Payable — Shop Fitters ₦1,250
  (Fixtures bought on credit)

Aug 17: Dr Accounts Payable — Shop Fitters ₦1,250 / Cr Cash ₦1,250
  (Settled creditor in full)

LEDGER BALANCES:
  Cash: ₦10,000 − ₦4,500 − ₦1,250 = ₦4,250 Dr
  Capital: ₦10,000 Cr
  Van: ₦4,500 Dr
  Fixtures: ₦1,250 Dr
  Accounts Payable — Shop Fitters: ₦1,250 Dr − ₦1,250 Cr = NIL (closed)

TRIAL BALANCE (17 Aug 2013):
  Account           Dr (₦)    Cr (₦)
  Cash               4,250
  Van                4,500
  Fixtures           1,250
  Capital                      10,000
  TOTALS            10,000    10,000 ✓`,
    explain: "After Shop Fitters is paid (Aug 17), the creditor account closes to zero — it should not appear in the trial balance. The trial balance contains only three live accounts: Cash, Van, Fixtures (all assets), and Capital (equity). Total assets = ₦10,000 = Capital ₦10,000. A clean demonstration of the accounting equation.",
  },
  {
    id: 20, sec: "S6", num: "Q20", difficulty: "Hard",
    title: "Journal Entries — A Hirst (March 20X3)",
    text: "Record the following transactions in the books of A Hirst:\n\nMar 1 — Started with ₦4,000 cash\nMar 3 — Deposited ₦2,000 into bank\nMar 6 — Bought inventory on credit from I McNulty ₦560\nMar 11 — Bought office equipment by cheque ₦1,500\nMar 13 — Returned inventory ₦300 to I McNulty\nMar 17 — Sold goods on credit to S Brown ₦400\nMar 22 — Purchased fixtures on credit from Westley Supplies ₦500\nMar 28 — S Brown returned goods ₦200\nMar 31 — Settled account with McNulty by cheque ₦260\n\nExtract a Trial Balance as at 31 March 20X3.",
    marks: "Ledger & Trial Balance — 10 Marks",
    hint: "Returns inward (from customers) = Dr Returns Inward / Cr Accounts Receivable. Returns outward (to suppliers) = Dr Accounts Payable / Cr Returns Outward.",
    answer: `JOURNAL ENTRIES:
Mar 1: Dr Cash ₦4,000 / Cr Capital ₦4,000
Mar 3: Dr Bank ₦2,000 / Cr Cash ₦2,000
Mar 6: Dr Purchases ₦560 / Cr I McNulty (AP) ₦560
Mar 11: Dr Office Equipment ₦1,500 / Cr Bank ₦1,500
Mar 13: Dr I McNulty (AP) ₦300 / Cr Returns Outward ₦300
Mar 17: Dr S Brown (AR) ₦400 / Cr Sales ₦400
Mar 22: Dr Fixtures ₦500 / Cr Westley Supplies (AP) ₦500
Mar 28: Dr Returns Inward ₦200 / Cr S Brown (AR) ₦200
Mar 31: Dr I McNulty (AP) ₦260 / Cr Bank ₦260

ACCOUNT BALANCES:
  Cash: ₦4,000 − ₦2,000 = ₦2,000 Dr
  Bank: ₦2,000 − ₦1,500 − ₦260 = ₦240 Dr
  Purchases: ₦560 Dr
  Office Equipment: ₦1,500 Dr
  Fixtures: ₦500 Dr
  S Brown (AR): ₦400 − ₦200 = ₦200 Dr
  Returns Inward: ₦200 Dr
  Capital: ₦4,000 Cr
  I McNulty: ₦560 − ₦300 − ₦260 = NIL
  Returns Outward: ₦300 Cr
  Sales: ₦400 Cr
  Westley Supplies: ₦500 Cr

TRIAL BALANCE (31 Mar 20X3):
  Account              Dr(₦)   Cr(₦)
  Cash                 2,000
  Bank                   240
  Purchases              560
  Office Equipment     1,500
  Fixtures               500
  S Brown (AR)           200
  Returns Inward         200
  Capital                        4,000
  Returns Outward                  300
  Sales                            400
  Westley Supplies (AP)            500
  TOTALS               5,200     5,200 ✓`,
    explain: "Key: McNulty's account closes to zero (₦560 − ₦300 returns − ₦260 cash = 0). S Brown nets to ₦200 (₦400 sale − ₦200 return). Returns Inward (sales returns) is a contra-income account on the debit side. Returns Outward (purchase returns) is a contra-expense on the credit side. Westley Supplies remains as a creditor since it was not paid in March.",
  },
  // ── MODULE 7 ───────────────────────────────────────────────────────────────
  {
    id: 21, sec: "S7", num: "Q21", difficulty: "Hard",
    title: "Bank Reconciliation — Tatiana Foods Ventures (Jan 2013)",
    text: "Using the bank ledger and bank statement for Tatiana Foods Ventures provided in the case materials:\n\na) Identify all differences between the cash book and bank statement\nb) Prepare the Bank Reconciliation Statement for January 2013\nc) List FIVE reasons why a business cash book and bank statement may disagree",
    marks: "Bank Reconciliation — 10 Marks",
    hint: "Tatiana's cash book closing balance = ₦738,000. Bank statement closing balance = ₦985,000. Find items in one but not the other. Note: cheque GTB Cq9 was dishonoured (returned). Uduakobong cheque ₦490,000 in cash book vs ₦49,000 on statement.",
    answer: `DIFFERENCES IDENTIFIED:
• Peterson Co. ₦95,000 — in cash book (credit), NOT on bank statement (outstanding cheque)
• TT Ventures ₦194,000 — in cash book (debit), NOT on bank statement (deposit in transit)
• Uduakobong: Cash book shows ₦490,000 but bank statement shows ₦49,000 → DIFFERENCE ₦441,000 (possible transposition error in cash book — bank correct)
• GTB Cq9 (XY Ventures ₦83,000) — deposited then returned (dishonoured) — cash book shows receipt but bank reversed it → need to reduce cash book by ₦83,000
• Bank Charges ₦12,000 — on bank statement, NOT in cash book
• Bank statement credits XY Ventures ₦83,000 then REVERSES it same month

ADJUSTED CASH BOOK BALANCE:
  Per Cash Book:                       ₦738,000
  Less: Bank charges (not in CB)        (₦12,000)
  Less: Dishonoured cheque XY Vent.     (₦83,000)
  Less: Uduakobong error (490k−49k)    (₦441,000)
  Adjusted Cash Book Balance:          ₦202,000

BANK RECONCILIATION STATEMENT (Jan 2013):
  Balance per Bank Statement           ₦985,000
  Less: Outstanding cheque — Peterson   (₦95,000)
  Add: Deposit in transit — TT Ventures ₦194,000
  Less: Uduakobong error (BS correct)       NIL
  Adjusted Bank Balance:              ₦1,084,000

  NOTE: Significant discrepancy remains — suggesting additional unreconciled items. Students should flag the Uduakobong ₦441,000 discrepancy as requiring investigation.

FIVE REASONS FOR DISAGREEMENT:
1. Outstanding cheques (issued but not yet presented to bank)
2. Deposits in transit (lodged by business but not yet credited by bank)
3. Bank charges and interest not yet recorded in cash book
4. Standing orders/direct debits paid by bank not recorded in cash book
5. Dishonoured (bounced/returned) cheques reversed by bank but not in cash book`,
    explain: "Bank reconciliation is one of the most practically important accounting skills. The Tatiana case involves a dishonoured cheque (reversal), a possible transposition error (₦490,000 vs ₦49,000), and unrecorded bank charges. In practice, reconciling items must be investigated — they could signal fraud or serious errors.",
  },
  {
    id: 22, sec: "S7", num: "Q22", difficulty: "Hard",
    title: "Adjusted Cash Book & Reconciliation — Jerry (31 Dec 2004)",
    text: "Jerry's cash book showed a debit balance of ₦29,520 and his bank statement showed ₦26,500. Investigate and reconcile using the following:\n\ni) Cheque ₦1,960 in cash book, not on bank statement\nii) Unpresented cheques totalling ₦3,740\niii) Payment side of cash book undercast by ₦2,000\niv) Standing order ₦1,260 not posted in cash book\nv) Bill of Exchange ₦1,340 paid by bank on Jerry's behalf — not in cash book\nvi) Dividends ₦1,240 credited to account by bank — not in cash book\nvii) Payment ₦1,440 by Okocha charged in error to Jerry's account\n\nPrepare: (a) Adjusted Cash Book and (b) Bank Reconciliation Statement",
    marks: "Bank Reconciliation — 8 Marks",
    hint: "Adjustments to cash book: items bank has done that Jerry hasn't recorded. Adjustments to bank statement: items Jerry has recorded that bank hasn't yet processed. The undercast means the payment column total is ₦2,000 TOO LOW — so cash book balance is ₦2,000 too high.",
    answer: `(a) ADJUSTED CASH BOOK:
  Balance per Cash Book                ₦29,520
  ADD:
  + Dividends (vi) credited by bank     +₦1,240
  LESS:
  − Cash book undercast (iii) (payments too low by ₦2,000, so balance too high) −₦2,000
  − Standing order (iv) not posted     −₦1,260
  − Bill of Exchange (v) paid by bank  −₦1,340
  ADJUSTED CASH BOOK BALANCE           ₦26,160

(b) BANK RECONCILIATION STATEMENT (31 Dec 2004):
  Balance per Bank Statement           ₦26,500
  ADD:
  + Cheque (i) in CB not on BS         +₦1,960
  + Bank error — Okocha (vii) debited in error +₦1,440
  LESS:
  − Unpresented cheques (ii)           −₦3,740
  ADJUSTED BANK BALANCE                ₦26,160 ✓

BOTH AGREE AT ₦26,160 ✓

KEY NOTES:
• (iii) Undercast payments = cash book OVERSTATES the balance by ₦2,000 → DEDUCT
• (vii) Bank error — Okocha's payment wrongly charged to Jerry → ADD BACK to bank statement (bank will correct this)
• (i) Deposit in transit → ADD to bank statement balance`,
    explain: "The undercast (iii) is a classic trap: if the payments column is undercast by ₦2,000, it means payments are understated → cash book balance is overstated by ₦2,000 → we must DEDUCT from the cash book. Item (vii) is a bank error — not Jerry's problem — so we add it back to the bank statement. The bank will reverse this charge when notified.",
  },
  {
    id: 23, sec: "S7", num: "Q23", difficulty: "Hard",
    title: "Bank Reconciliation — Chike Obi (31 Dec 20X8)",
    text: "Chike Obi's cash book showed a debit balance of ₦1,500 and his bank statement showed a credit balance of ₦2,950 at 31 December 20X8.\n\nNot in cash book:\n• Dividends paid direct to bank: ₦240\n• Tax refund credit transfer: ₦260\n• Bank charges: ₦30\n• Direct debit — club subscription: ₦70\n• Standing order — loan repayment: ₦200\n• Deposit account transfer to current account: ₦1,400\n\nNot yet on bank statement:\n• Cheques to T Carrick ₦250 and M Cisse ₦290 (drawn, not presented)\n• Cash and cheques paid in ₦690 on 31 Dec (not credited until 2 Jan)\n\nRequired: (a) Update the Cash Book and balance it. (b) Prepare Bank Reconciliation Statement.",
    marks: "Bank Reconciliation — 8 Marks",
    hint: "The deposit account transfer is a receipt for the current account. Update cash book first, then reconcile.",
    answer: `(a) UPDATED CASH BOOK (Bank column):
  Balance b/d                      ₦1,500 Dr
  ADD (receipts to record):
  Dividends                           +₦240
  Tax refund                          +₦260
  Deposit a/c transfer              +₦1,400
  DEDUCT (payments to record):
  Bank charges                          −₦30
  Club subscription (DD)                −₦70
  Standing order (loan)               −₦200
  UPDATED BALANCE                   ₦3,100 Dr

(b) BANK RECONCILIATION STATEMENT (31 Dec 20X8):
  Balance per Bank Statement         ₦2,950 Cr
  ADD: Deposits in transit (₦690)     +₦690
  LESS: Unpresented cheques:
    T Carrick                          −₦250
    M Cisse                            −₦290
  ADJUSTED BANK BALANCE             ₦3,100 ✓

BOTH AGREE AT ₦3,100 ✓`,
    explain: "The deposit account transfer (₦1,400) is often missed — it is a receipt to the current account cash book, credited by the bank. After updating the cash book for all items the bank knows about but Chike doesn't, the two balances should agree after adjusting for timing differences (in-transit items).",
  },
  {
    id: 24, sec: "S7", num: "Q24", difficulty: "Hard",
    title: "Income Statement & Balance Sheet — M Dawe",
    text: "From the trial balance of M Dawe (first year of trading, year ended 31 March 20X2), prepare: (a) an Income Statement, and (b) a Statement of Financial Position.\n\nTrial Balance:\nSales ₦23,414 Cr | Purchases ₦16,111 Dr | Capital ₦40,000 Cr | AR ₦6,019 Dr | AP ₦5,645 Cr | Bank ₦3,765 Dr | Cash ₦129 Dr | Premises ₦27,000 Dr | Fixtures ₦7,500 Dr | Equipment ₦4,000 Dr | Wages ₦1,900 Dr | Motor vehicles ₦279 Dr | Drawings ₦1,400 Dr | Sundries ₦456 Dr | Rent ₦500 Dr\n\nClosing Inventory: ₦4,344",
    marks: "Financial Statements — 10 Marks",
    hint: "COGS = Opening Inventory + Purchases − Closing Inventory. Since it's the first year, opening inventory = 0. Net Profit adds to Capital; Drawings reduces it.",
    answer: `INCOME STATEMENT for year ended 31 March 20X2:
  Sales Revenue                      ₦23,414
  Less: Cost of Goods Sold:
    Opening Inventory                     ₦0
    Add: Purchases                   ₦16,111
    Less: Closing Inventory          (₦4,344)
  COST OF GOODS SOLD                ₦11,767
  GROSS PROFIT                      ₦11,647

  Less: Operating Expenses:
    Wages                             ₦1,900
    Rent                                ₦500
    Sundries                            ₦456
    Motor Expenses (vehicles)*          ₦279
  TOTAL EXPENSES                     ₦3,135
  NET PROFIT                         ₦8,512
  *Motor vehicles at ₦279 likely is motor expenses (unusual low value)

STATEMENT OF FINANCIAL POSITION as at 31 March 20X2:
  NON-CURRENT ASSETS:
    Premises                         ₦27,000
    Fixtures & Fittings               ₦7,500
    Equipment                         ₦4,000
  Total Non-Current Assets           ₦38,500

  CURRENT ASSETS:
    Inventory (closing)               ₦4,344
    Accounts Receivable               ₦6,019
    Bank                              ₦3,765
    Cash                                ₦129
  Total Current Assets               ₦14,257

  TOTAL ASSETS                       ₦52,757

  CURRENT LIABILITIES:
    Accounts Payable                  ₦5,645

  EQUITY:
    Opening Capital                  ₦40,000
    Add: Net Profit                   ₦8,512
    Less: Drawings                   (₦1,400)
    CLOSING CAPITAL                  ₦47,112

  TOTAL LIABILITIES + EQUITY        ₦52,757 ✓`,
    explain: "Key principles: (1) COGS uses opening + purchases − closing inventory. Year 1 has no opening inventory. (2) Net profit is added to capital; drawings reduce it. (3) The balance sheet must balance: Total Assets = Total Liabilities + Equity. Any imbalance signals an error in extracting figures from the trial balance.",
  },
];

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────
const LS_KEY = "novelle_exam_v5";
const fmt = (s) => `${Math.floor(s/60).toString().padStart(2,"0")}:${(s%60).toString().padStart(2,"0")}`;
const deepClone = (v) => JSON.parse(JSON.stringify(v));

const DIFFICULTY_COLOR = { Easy: "#2B8A3E", Medium: "#E67700", Hard: "#C92A2A" };

function makeBlankTable(name = "Workspace") {
  return { id: Date.now() + Math.random(), name, headers: ["Account","Dr (₦)","Cr (₦)"], rows: [["","",""],["","",""],["","",""],["","",""]], totalRow: false };
}

const TEMPLATES = {
  journal: { label:"Journal Entry", headers:["Date","Account","Dr (₦)","Cr (₦)","Narration"], rows:[["","","","",""],["","","","",""],["","","","",""],["","","","",""]] },
  ledger: { label:"T-Account Ledger", headers:["Date","Details","Dr (₦)","Date","Details","Cr (₦)"], rows:[["","","","","",""],["","","","","",""],["","","","","",""],["Balance c/d","","","Balance b/d","",""]] },
  trialbalance: { label:"Trial Balance", headers:["Account","Debit (₦)","Credit (₦)"], rows:[["","",""],["","",""],["","",""],["","",""],["","",""],["TOTAL","",""]] },
  accounting_eq: { label:"Accounting Equation", headers:["Transaction","Assets (₦)","Liabilities (₦)","Equity (₦)"], rows:[["","","",""],["","","",""],["","","",""],["NET","","",""]] },
  income_stmt: { label:"Income Statement", headers:["Item","₦","₦"], rows:[["Revenue","",""],["Less: COGS","",""],["Gross Profit","",""],["Less: Expenses","",""],["Net Profit","",""]] },
  balance_sheet: { label:"Balance Sheet", headers:["Item","₦","₦"], rows:[["Non-Current Assets","",""],["Current Assets","",""],["TOTAL ASSETS","",""],["Liabilities","",""],["Equity","",""],["TOTAL L+E","",""]] },
  bank_rec: { label:"Bank Reconciliation", headers:["Item","₦"], rows:[["Balance per Bank Statement",""],["Add: Deposits in Transit",""],["Less: Outstanding Cheques",""],["Adjusted Bank Balance",""],["---",""],["Adjusted Cash Book Balance",""]] },
};

function makeInitialState() {
  return { answers:{}, workspaces:{}, notes:{}, flagged:[], timerSecs:5400, submitted:false, darkMode:false, practiceMode:false };
}

// ─────────────────────────────────────────────────────────────────────────────
// EDITABLE TABLE COMPONENT
// ─────────────────────────────────────────────────────────────────────────────
function EditableTable({ table, onChange, onDelete, showDelete, dark }) {
  const T = { border: dark?"#334155":"#e2e8f0", bg: dark?"#0f172a":"#fff", secBg: dark?"#1e293b":"#f1f5f9", text: dark?"#e2e8f0":"#1e293b", sub: dark?"#94a3b8":"#64748b" };
  const upd = (ri, ci, val, isHeader) => {
    const t = deepClone(table);
    if (isHeader) t.headers[ci] = val;
    else t.rows[ri][ci] = val;
    onChange(t);
  };
  const addRow = () => { const t=deepClone(table); t.rows.push(t.headers.map(()=>"")); onChange(t); };
  const delRow = () => { const t=deepClone(table); if(t.rows.length>1){t.rows.pop();onChange(t);} };
  const addCol = () => { const t=deepClone(table); t.headers.push(""); t.rows=t.rows.map(r=>[...r,""]); onChange(t); };
  const delCol = () => { const t=deepClone(table); if(t.headers.length>1){t.headers.pop();t.rows=t.rows.map(r=>r.slice(0,-1));onChange(t);} };

  const inp = { border:"none", background:"transparent", width:"100%", padding:"5px 7px", fontSize:12, fontFamily:"inherit", color:T.text, outline:"none" };

  return (
    <div style={{marginBottom:8,border:`1px solid ${T.border}`,borderRadius:6,overflow:"hidden"}}>
      <div style={{display:"flex",alignItems:"center",gap:5,padding:"5px 8px",background:T.secBg,flexWrap:"wrap",borderBottom:`1px solid ${T.border}`}}>
        <input value={table.name} onChange={e=>{const t=deepClone(table);t.name=e.target.value;onChange(t);}} style={{...inp,fontWeight:600,fontSize:11,color:T.sub,flex:1,minWidth:80}} />
        {[["+ Row",addRow],["− Row",delRow],["+ Col",addCol],["− Col",delCol]].map(([l,fn])=>(
          <button key={l} onClick={fn} style={{padding:"2px 7px",fontSize:10,border:`0.5px solid ${T.border}`,borderRadius:4,background:T.bg,color:T.sub,cursor:"pointer"}}>{l}</button>
        ))}
        <button onClick={()=>{const t=deepClone(table);t.totalRow=!t.totalRow;onChange(t);}} style={{padding:"2px 7px",fontSize:10,border:`0.5px solid ${table.totalRow?"#0CA678":T.border}`,borderRadius:4,background:table.totalRow?(dark?"#064e3b":"#ecfdf5"):T.bg,color:table.totalRow?"#0CA678":T.sub,cursor:"pointer"}}>Total {table.totalRow?"on":"off"}</button>
        {showDelete && <button onClick={onDelete} style={{padding:"2px 7px",fontSize:10,border:"0.5px solid #dc2626",borderRadius:4,background:dark?"#450a0a":"#fef2f2",color:"#dc2626",cursor:"pointer"}}>✕</button>}
      </div>
      <div style={{overflowX:"auto"}}>
        <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
          <thead><tr>{table.headers.map((h,ci)=>(
            <th key={ci} style={{padding:0,border:`0.5px solid ${T.border}`,background:T.secBg}}>
              <input style={{...inp,fontWeight:600,color:T.sub}} value={h} onChange={e=>upd(0,ci,e.target.value,true)} placeholder={`Col ${ci+1}`} />
            </th>
          ))}</tr></thead>
          <tbody>{table.rows.map((row,ri)=>{
            const isTot=table.totalRow&&ri===table.rows.length-1;
            return (<tr key={ri} style={{background:isTot?(dark?"#0f2d1e":"#f0fdf4"):ri%2===0?T.bg:T.secBg}}>
              {row.map((cell,ci)=>(
                <td key={ci} style={{padding:0,border:`0.5px solid ${T.border}`,borderTop:isTot?`2px solid ${dark?"#1e5738":"#16a34a"}`:undefined}}>
                  <input style={{...inp,fontWeight:isTot?600:400}} value={cell} onChange={e=>upd(ri,ci,e.target.value,false)} placeholder="—" />
                </td>
              ))}
            </tr>);
          })}</tbody>
        </table>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN APP
// ─────────────────────────────────────────────────────────────────────────────
export default function ExamPlatform() {
  const [state, setState] = useState(()=>{
    try { const s=localStorage.getItem(LS_KEY); return s?{...makeInitialState(),...JSON.parse(s)}:makeInitialState(); } catch { return makeInitialState(); }
  });
  const [current, setCurrent] = useState(0);
  const [screen, setScreen] = useState("exam"); // exam|review|result|admin
  const [search, setSearch] = useState("");
  const [activePanel, setActivePanel] = useState("case");
  const [lastSaved, setLastSaved] = useState(null);
  const timerRef = useRef(null);
  const dark = state.darkMode;
  const q = QUESTIONS[current];

  const save = useCallback((s)=>{ try{localStorage.setItem(LS_KEY,JSON.stringify(s));setLastSaved(new Date());}catch{} },[]);
  useEffect(()=>{ const i=setInterval(()=>save(state),5000); return()=>clearInterval(i); },[state,save]);

  useEffect(()=>{
    if(state.submitted||screen==="result") return;
    timerRef.current=setInterval(()=>{
      setState(prev=>{
        const n={...prev,timerSecs:prev.timerSecs-1};
        if(n.timerSecs<=0){clearInterval(timerRef.current);return{...n,submitted:true};}
        return n;
      });
    },1000);
    return()=>clearInterval(timerRef.current);
  },[state.submitted,screen]);

  const upd = p=>setState(prev=>({...prev,...p}));

  const T = {
    bg: dark?"#0f172a":"#f1f5f9", panel: dark?"#1e293b":"#ffffff", border: dark?"#334155":"#e2e8f0",
    text: dark?"#e2e8f0":"#1e293b", sub: dark?"#94a3b8":"#64748b", accent:"#3B5BDB",
    hdr: dark?"#0f172a":"#1e293b", scenBg: dark?"#172033":"#eff6ff", scenBorder: dark?"#1e3a5f":"#bfdbfe",
    inp: dark?"#0f172a":"#f8fafc", tag: dark?"#1e3a5f":"#dbeafe", tagT: dark?"#93c5fd":"#1d4ed8",
    okBg: dark?"#064e3b":"#f0fdf4", okBorder: dark?"#065f46":"#bbf7d0", okText: dark?"#6ee7b7":"#15803d",
    infoBg: dark?"#1e3a5f":"#eff6ff", infoText: dark?"#93c5fd":"#1d4ed8",
  };

  // Workspace helpers
  const getWS = id=>state.workspaces[id]||[makeBlankTable()];
  const setWS = (id,ws)=>upd({workspaces:{...state.workspaces,[id]:ws}});
  const addWS = id=>setWS(id,[...getWS(id),makeBlankTable(`Workspace ${getWS(id).length+1}`)]);
  const delWS = (id,i)=>{ const ws=getWS(id).filter((_,j)=>j!==i); setWS(id,ws.length?ws:[makeBlankTable()]); };
  const updWS = (id,i,t)=>{ const ws=deepClone(getWS(id)); ws[i]=t; setWS(id,ws); };
  const insertTpl = (id,k)=>{ const t=TEMPLATES[k]; setWS(id,[...getWS(id),{id:Date.now(),name:t.label,headers:[...t.headers],rows:deepClone(t.rows),totalRow:false}]); };

  const sec = SECTIONS.find(s=>s.id===q.sec)||SECTIONS[0];
  const answered = QUESTIONS.filter(q=>state.answers[q.id]?.trim()).length;

  const filteredSecs = search
    ? SECTIONS.filter(s=>s.title.toLowerCase().includes(search.toLowerCase())||s.narrative.toLowerCase().includes(search.toLowerCase()))
    : [sec];

  const exportPDF = ()=>{
    const win=window.open("","_blank"); if(!win) return;
    let h=`<html><head><title>Exam Answers</title><style>body{font-family:Arial,sans-serif;padding:32px;font-size:13px;color:#1e293b}h1{font-size:18px}h2{font-size:14px;color:#1d4ed8;margin:20px 0 4px}pre{background:#f1f5f9;padding:10px;border-radius:4px;font-size:12px;white-space:pre-wrap}hr{border:none;border-top:1px solid #e2e8f0;margin:14px 0}</style></head><body>`;
    h+=`<h1>Novelle Café & ELTP — Retail Track Exam Answers</h1><p style="color:#64748b">Exported: ${new Date().toLocaleString()}</p><hr>`;
    QUESTIONS.forEach(q=>{
      h+=`<h2>${q.num}: ${q.title} (${q.difficulty})</h2><p><strong>Q:</strong> ${q.text.replace(/\n/g,"<br>")}</p>`;
      h+=`<pre>${state.answers[q.id]?.trim()||"(not answered)"}</pre>`;
      const ws=state.workspaces[q.id];
      if(ws) ws.forEach(t=>{
        h+=`<p><strong>Table: ${t.name}</strong></p><table border="1" cellpadding="4" cellspacing="0" style="border-collapse:collapse;font-size:11px"><tr>`;
        t.headers.forEach(hh=>h+=`<th style="background:#f1f5f9">${hh}</th>`); h+="</tr>";
        t.rows.forEach(r=>{h+="<tr>";r.forEach(c=>h+=`<td>${c||""}</td>`);h+="</tr>";}); h+="</table><br>";
      });
      if(state.notes[q.id]) h+=`<p><strong>Notes:</strong> ${state.notes[q.id]}</p>`;
      h+=`<hr>`;
    });
    h+="</body></html>"; win.document.write(h); win.document.close(); win.print();
  };

  const btn = (variant="default",extra={})=>({ padding:"6px 13px",fontSize:12,fontWeight:500,borderRadius:6,cursor:"pointer",display:"inline-flex",alignItems:"center",gap:4,border:variant==="primary"?"none":`1.5px solid ${T.border}`,background:variant==="primary"?T.accent:variant==="danger"?(dark?"#450a0a":"#fef2f2"):T.panel,color:variant==="primary"?"#fff":variant==="danger"?"#dc2626":T.sub,...extra });

  if(screen==="result") return <ResultScreen T={T} dark={dark} state={state} questions={QUESTIONS} sections={SECTIONS} onRestart={()=>{setState(makeInitialState());setCurrent(0);setScreen("exam");}} onExport={exportPDF} btn={btn} />;

  if(screen==="admin") return (
    <div style={{padding:24,maxWidth:700,margin:"0 auto",color:T.text,fontFamily:"'Inter',system-ui,sans-serif"}}>
      <button onClick={()=>setScreen("exam")} style={{...btn(),marginBottom:20}}>← Back</button>
      <div style={{fontSize:17,fontWeight:600,marginBottom:16}}>Admin Panel</div>
      {[[60,"60 min"],[90,"90 min"],[120,"120 min"]].map(([m,l])=>(
        <button key={m} onClick={()=>upd({timerSecs:m*60})} style={{...btn(state.timerSecs===m*60?"primary":"default"),marginRight:6,marginBottom:12}}>{l}</button>
      ))}
      <div style={{marginBottom:12}}>
        <button onClick={exportPDF} style={{...btn(),marginRight:8}}>Export PDF</button>
        <button onClick={()=>{if(window.confirm("Clear all data?")){localStorage.removeItem(LS_KEY);window.location.reload();}}} style={{...btn("danger")}}>Clear saved data</button>
      </div>
      <div style={{fontSize:12,color:T.sub}}>Questions: {QUESTIONS.length} · Sections: {SECTIONS.length} · Answered: {answered}</div>
    </div>
  );

  return (
    <div style={{background:T.bg,minHeight:"100vh",fontFamily:"'Inter',system-ui,sans-serif",color:T.text}}>
      {/* TOP BAR */}
      <div style={{background:T.hdr,padding:"9px 16px",display:"flex",alignItems:"center",justifyContent:"space-between",flexWrap:"wrap",gap:8}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <span style={{fontSize:13,fontWeight:600,color:"#fff"}}>🔒 Novelle Café & ELTP Retail Track</span>
          <span style={{fontSize:10,color:"#94a3b8",padding:"2px 7px",background:"#1e293b",borderRadius:10}}>{state.practiceMode?"Practice":"Exam"} · {QUESTIONS.length} Questions</span>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          {lastSaved&&<span style={{fontSize:10,color:"#64748b"}}>Saved {lastSaved.toLocaleTimeString()}</span>}
          <span style={{fontSize:13,fontWeight:600,color:state.timerSecs<300?"#f87171":"#fbbf24",fontFamily:"monospace"}}>{fmt(state.timerSecs)}</span>
          <button onClick={()=>{save(state);setLastSaved(new Date());}} style={{...btn(),fontSize:11,padding:"4px 9px",color:"#94a3b8",background:"#1e293b",border:"1px solid #334155"}}>💾 Save</button>
          <button onClick={()=>upd({darkMode:!dark})} style={{...btn(),fontSize:11,padding:"4px 9px",color:"#94a3b8",background:"#1e293b",border:"1px solid #334155"}}>{dark?"☀️":"🌙"}</button>
          <button onClick={()=>setScreen("admin")} style={{...btn(),fontSize:11,padding:"4px 9px",color:"#94a3b8",background:"#1e293b",border:"1px solid #334155"}}>⚙️</button>
        </div>
      </div>

      {/* PROGRESS */}
      <div style={{height:3,background:dark?"#334155":"#e2e8f0"}}>
        <div style={{height:3,width:`${(answered/QUESTIONS.length)*100}%`,background:T.accent,transition:"width 0.4s"}} />
      </div>

      {/* QUESTION NAV */}
      <div style={{background:dark?"#0f172a":"#fff",borderBottom:`1px solid ${T.border}`,padding:"9px 16px",display:"flex",alignItems:"center",gap:4,flexWrap:"wrap"}}>
        {QUESTIONS.map((qq,i)=>{
          const isCur=i===current,isAns=!!state.answers[qq.id]?.trim(),isFlag=state.flagged.includes(qq.id);
          const sec=SECTIONS.find(s=>s.id===qq.sec);
          return (
            <button key={qq.id} onClick={()=>{setCurrent(i);setScreen("exam");}} title={`${qq.num}: ${qq.title}`} style={{width:28,height:28,borderRadius:"50%",border:isCur?`2px solid ${T.accent}`:isFlag?"2px solid #f59e0b":`1.5px solid ${T.border}`,background:isCur?T.accent:isAns?(dark?"#064e3b":"#dcfce7"):T.panel,color:isCur?"#fff":isAns?(dark?"#6ee7b7":"#16a34a"):isFlag?"#f59e0b":T.sub,fontSize:10,fontWeight:600,cursor:"pointer",position:"relative"}} >
              {i+1}
              {sec&&<span style={{position:"absolute",bottom:-2,right:-2,width:6,height:6,borderRadius:"50%",background:sec.color,border:`1px solid ${T.bg}`}} />}
            </button>
          );
        })}
        <div style={{marginLeft:"auto",display:"flex",gap:7,alignItems:"center",flexWrap:"wrap"}}>
          <span style={{fontSize:11,color:T.sub}}>{answered}/{QUESTIONS.length} answered</span>
          <button onClick={()=>setScreen("review")} style={{...btn(),fontSize:11,padding:"4px 9px"}}>Review</button>
          <button onClick={()=>{clearInterval(timerRef.current);upd({submitted:true});setScreen("result");}} style={{...btn("danger"),fontSize:11,padding:"4px 9px"}}>Submit</button>
        </div>
      </div>

      {screen==="review" ? (
        <ReviewScreen T={T} dark={dark} state={state} questions={QUESTIONS} sections={SECTIONS} setCurrent={i=>{setCurrent(i);setScreen("exam");}} onSubmit={()=>{clearInterval(timerRef.current);upd({submitted:true});setScreen("result");}} btn={btn} />
      ) : (
        <div style={{display:"grid",gridTemplateColumns:"272px 1fr",minHeight:"calc(100vh - 112px)"}}>
          {/* LEFT PANEL */}
          <div style={{borderRight:`1px solid ${T.border}`,background:T.panel,display:"flex",flexDirection:"column",height:"calc(100vh - 112px)",position:"sticky",top:112,overflow:"hidden"}}>
            <div style={{display:"flex",borderBottom:`1px solid ${T.border}`}}>
              {[["case","📖 Case Study"],["notes","📝 Notes"]].map(([id,label])=>(
                <button key={id} onClick={()=>setActivePanel(id)} style={{flex:1,padding:"8px 0",fontSize:11,fontWeight:activePanel===id?600:400,border:"none",background:activePanel===id?T.bg:T.panel,color:activePanel===id?T.accent:T.sub,cursor:"pointer",borderBottom:activePanel===id?`2px solid ${T.accent}`:"none"}}>{label}</button>
              ))}
            </div>
            {activePanel==="case" ? (
              <div style={{flex:1,overflowY:"auto",padding:12}}>
                <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search all case materials…" style={{width:"100%",padding:"6px 9px",fontSize:11,border:`1px solid ${T.border}`,borderRadius:6,background:T.inp,color:T.text,marginBottom:10,outline:"none",boxSizing:"border-box"}} />
                {(search?filteredSecs:[sec]).map(s=>(
                  <div key={s.id} style={{marginBottom:12}}>
                    <div style={{display:"flex",alignItems:"center",gap:5,marginBottom:5}}>
                      <div style={{width:7,height:7,borderRadius:"50%",background:s.color}} />
                      <span style={{fontSize:10,fontWeight:700,color:s.color}}>{s.label}</span>
                      <span style={{fontSize:10,color:T.sub}}>— {s.title}</span>
                    </div>
                    <div style={{background:T.scenBg,border:`1px solid ${T.scenBorder}`,borderRadius:7,padding:11,fontSize:11,color:T.text,lineHeight:1.85,whiteSpace:"pre-wrap"}}>{s.narrative}</div>
                  </div>
                ))}
                {search&&filteredSecs.length===0&&<div style={{color:T.sub,fontSize:11,textAlign:"center",padding:16}}>No results</div>}
              </div>
            ) : (
              <div style={{flex:1,padding:12,display:"flex",flexDirection:"column"}}>
                <div style={{fontSize:11,color:T.sub,marginBottom:5}}>{q.num} — Private notes</div>
                <textarea value={state.notes[q.id]||""} onChange={e=>upd({notes:{...state.notes,[q.id]:e.target.value}})} placeholder="Type private notes here…" style={{flex:1,resize:"none",border:`1px solid ${T.border}`,borderRadius:6,padding:"8px 9px",fontSize:12,fontFamily:"inherit",background:T.inp,color:T.text,outline:"none"}} />
              </div>
            )}
          </div>

          {/* RIGHT: QUESTION */}
          <div style={{overflowY:"auto",padding:"18px 20px",background:T.bg}}>
            {/* Header */}
            <div style={{marginBottom:14}}>
              <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:8,flexWrap:"wrap"}}>
                <span style={{fontSize:10,padding:"2px 8px",borderRadius:10,background:T.tag,color:T.tagT,fontWeight:500}}>{sec.label} — {sec.title}</span>
                <span style={{fontSize:10,padding:"2px 8px",borderRadius:10,fontWeight:600,background:DIFFICULTY_COLOR[q.difficulty]+"22",color:DIFFICULTY_COLOR[q.difficulty]}}>{q.difficulty}</span>
              </div>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:10}}>
                <div style={{flex:1}}>
                  <div style={{fontSize:11,color:T.sub,marginBottom:3}}>{q.num} of {QUESTIONS.length} · {q.title}</div>
                  <div style={{fontSize:14,color:T.text,lineHeight:1.75,whiteSpace:"pre-wrap"}}>{q.text}</div>
                  <div style={{fontSize:11,color:T.sub,marginTop:5,fontStyle:"italic"}}>📋 {q.marks}</div>
                  {q.hint&&<div style={{marginTop:8,padding:"7px 10px",background:T.infoBg,border:`1px solid ${T.scenBorder}`,borderRadius:6,fontSize:11,color:T.infoText}}>💡 <strong>Hint:</strong> {q.hint}</div>}
                </div>
                <button onClick={()=>upd({flagged:state.flagged.includes(q.id)?state.flagged.filter(f=>f!==q.id):[...state.flagged,q.id]})} style={{...btn(),fontSize:11,padding:"4px 9px",border:`1.5px solid ${state.flagged.includes(q.id)?"#f59e0b":T.border}`,color:state.flagged.includes(q.id)?"#f59e0b":T.sub,background:state.flagged.includes(q.id)?(dark?"#451a03":"#fffbeb"):T.panel,flexShrink:0}}>
                  {state.flagged.includes(q.id)?"🚩 Flagged":"⚑ Flag"}
                </button>
              </div>
            </div>

            {/* Written answer */}
            <div style={{marginBottom:14}}>
              <div style={{fontSize:11,color:T.sub,marginBottom:4,fontWeight:500}}>Your written answer</div>
              <textarea value={state.answers[q.id]||""} onChange={e=>upd({answers:{...state.answers,[q.id]:e.target.value}})} placeholder="Write your full answer here — show all workings…" style={{width:"100%",minHeight:110,padding:"10px 11px",fontSize:13,fontFamily:"inherit",border:`1.5px solid ${state.answers[q.id]?.trim()?T.accent:T.border}`,borderRadius:8,background:T.inp,color:T.text,resize:"vertical",outline:"none",lineHeight:1.7,boxSizing:"border-box"}} />
            </div>

            {/* Template shortcuts */}
            <div style={{marginBottom:10}}>
              <div style={{display:"flex",alignItems:"center",gap:5,flexWrap:"wrap",marginBottom:7}}>
                <span style={{fontSize:11,color:T.sub,fontWeight:500}}>Insert template:</span>
                {Object.keys(TEMPLATES).map(k=>(
                  <button key={k} onClick={()=>insertTpl(q.id,k)} style={{...btn(),fontSize:10,padding:"3px 8px"}}>{TEMPLATES[k].label}</button>
                ))}
                <button onClick={()=>addWS(q.id)} style={{...btn("primary"),fontSize:10,padding:"3px 8px"}}>+ Blank table</button>
              </div>

              {/* Workspace tables */}
              {getWS(q.id).map((table,idx)=>(
                <EditableTable key={table.id} table={table} onChange={t=>updWS(q.id,idx,t)} onDelete={()=>delWS(q.id,idx)} showDelete={getWS(q.id).length>1} dark={dark} />
              ))}
            </div>

            {/* Practice mode */}
            {state.practiceMode&&(
              <div style={{marginBottom:14}}>
                <button onClick={()=>upd({flagged:state.flagged.includes(-q.id)?state.flagged.filter(f=>f!==-q.id):[...state.flagged,-q.id]})} style={{...btn(),fontSize:11,color:T.infoText}} onClick={()=>{const key=`revealed_${q.id}`;upd({notes:{...state.notes,[key]:state.notes[key]?"":"show"}});}}>
                  {state.notes[`revealed_${q.id}`]?"🙈 Hide model answer":"👁 Show model answer"}
                </button>
                {state.notes[`revealed_${q.id}`]&&(
                  <div style={{marginTop:10}}>
                    <div style={{background:T.okBg,border:`1px solid ${T.okBorder}`,borderRadius:8,padding:12,fontSize:12,color:T.okText,whiteSpace:"pre-wrap",lineHeight:1.7,marginBottom:7}}><strong>Model answer:</strong>{"\n"}{q.answer}</div>
                    <div style={{background:T.infoBg,border:`1px solid ${T.scenBorder}`,borderRadius:8,padding:12,fontSize:12,color:T.infoText,lineHeight:1.7}}><strong>Explanation:</strong> {q.explain}</div>
                  </div>
                )}
              </div>
            )}

            {/* Bottom nav */}
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",paddingTop:14,borderTop:`1px solid ${T.border}`,flexWrap:"wrap",gap:8}}>
              <button onClick={()=>setCurrent(c=>Math.max(0,c-1))} disabled={current===0} style={{...btn(),opacity:current===0?0.4:1}}>← Previous</button>
              <div style={{display:"flex",gap:7,alignItems:"center",flexWrap:"wrap"}}>
                <button onClick={()=>upd({practiceMode:!state.practiceMode})} style={{...btn(),fontSize:11}}>{state.practiceMode?"📝 Exam mode":"🎓 Practice mode"}</button>
                {current<QUESTIONS.length-1
                  ?<button onClick={()=>setCurrent(c=>c+1)} style={btn("primary")}>Next →</button>
                  :<button onClick={()=>setScreen("review")} style={btn("primary")}>Review & Submit →</button>}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// REVIEW SCREEN
// ─────────────────────────────────────────────────────────────────────────────
function ReviewScreen({T,dark,state,questions,sections,setCurrent,onSubmit,btn}) {
  const secGroups = sections.map(s=>({...s,qs:questions.filter(q=>q.sec===s.id)}));
  return (
    <div style={{padding:22,maxWidth:820,margin:"0 auto",color:T.text,fontFamily:"'Inter',system-ui,sans-serif"}}>
      <div style={{fontSize:17,fontWeight:600,marginBottom:4}}>Review your answers</div>
      <div style={{fontSize:12,color:T.sub,marginBottom:18}}>Click any question to return and edit. Green = answered · Orange = flagged · Red = unanswered.</div>
      {secGroups.map(sec=>(
        <div key={sec.id} style={{marginBottom:18}}>
          <div style={{fontSize:12,fontWeight:700,color:sec.color,marginBottom:8,display:"flex",alignItems:"center",gap:6}}>
            <div style={{width:8,height:8,borderRadius:"50%",background:sec.color}} />{sec.label} — {sec.title}
          </div>
          {sec.qs.map((q,i)=>{
            const ans=state.answers[q.id]?.trim();const flag=state.flagged.includes(q.id);
            return (
              <div key={q.id} onClick={()=>setCurrent(questions.indexOf(q))} style={{border:`1px solid ${T.border}`,borderLeft:`4px solid ${ans?"#16a34a":flag?"#f59e0b":"#dc2626"}`,borderRadius:8,padding:"10px 13px",marginBottom:7,cursor:"pointer",background:T.panel,display:"flex",justifyContent:"space-between",alignItems:"center",gap:10}}>
                <div>
                  <div style={{fontSize:11,color:T.sub,marginBottom:2}}>{q.num} · {q.difficulty}</div>
                  <div style={{fontSize:13,color:T.text}}>{q.title}</div>
                  {ans&&<div style={{fontSize:11,color:T.sub,marginTop:3,maxWidth:500,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{ans}</div>}
                </div>
                <span style={{fontSize:10,padding:"2px 8px",borderRadius:10,background:ans?(dark?"#064e3b":"#dcfce7"):flag?(dark?"#451a03":"#fffbeb"):(dark?"#450a0a":"#fef2f2"),color:ans?(dark?"#6ee7b7":"#16a34a"):flag?"#f59e0b":"#dc2626",flexShrink:0}}>{ans?"✓ Done":flag?"⚑ Flagged":"✗ Missing"}</span>
              </div>
            );
          })}
        </div>
      ))}
      <div style={{display:"flex",gap:10,justifyContent:"center",marginTop:20,flexWrap:"wrap"}}>
        <button onClick={()=>setCurrent(0)} style={btn()}>← Back to exam</button>
        <button onClick={onSubmit} style={{...btn("danger"),background:"#dc2626",color:"#fff",border:"none"}}>Submit exam →</button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// RESULT SCREEN
// ─────────────────────────────────────────────────────────────────────────────
function ResultScreen({T,dark,state,questions,sections,onRestart,onExport,btn}) {
  const [open,setOpen]=useState(null);
  const answered=questions.filter(q=>state.answers[q.id]?.trim()).length;
  const secGroups=sections.map(s=>({...s,qs:questions.filter(q=>q.sec===s.id)}));
  return (
    <div style={{padding:22,maxWidth:860,margin:"0 auto",color:T.text,fontFamily:"'Inter',system-ui,sans-serif"}}>
      <div style={{textAlign:"center",marginBottom:24}}>
        <div style={{fontSize:20,fontWeight:700,marginBottom:4}}>Exam submitted</div>
        <div style={{fontSize:12,color:T.sub,marginBottom:18}}>Novelle Café & ELTP Retail Track · {questions.length} questions</div>
        <div style={{width:84,height:84,borderRadius:"50%",border:"4px solid #3B5BDB",display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 16px",fontSize:22,fontWeight:700,color:"#3B5BDB"}}>{Math.round(answered/questions.length*100)}%</div>
        <div style={{display:"flex",justifyContent:"center",gap:10,flexWrap:"wrap",marginBottom:16}}>
          {[["Attempted",answered],["Skipped",questions.length-answered],["Flagged",state.flagged.length]].map(([l,v])=>(
            <div key={l} style={{background:T.panel,border:`1px solid ${T.border}`,borderRadius:8,padding:"8px 14px",textAlign:"center"}}>
              <div style={{fontSize:19,fontWeight:600}}>{v}</div><div style={{fontSize:11,color:T.sub}}>{l}</div>
            </div>
          ))}
        </div>
        <div style={{display:"flex",gap:8,justifyContent:"center",flexWrap:"wrap"}}>
          <button onClick={onRestart} style={btn()}>Restart</button>
          <button onClick={onExport} style={btn()}>Export PDF</button>
        </div>
      </div>

      {secGroups.map(sec=>(
        <div key={sec.id} style={{marginBottom:14}}>
          <div style={{fontSize:12,fontWeight:700,color:sec.color,marginBottom:8,display:"flex",alignItems:"center",gap:6}}>
            <div style={{width:7,height:7,borderRadius:"50%",background:sec.color}} />{sec.label} — {sec.title}
          </div>
          {sec.qs.map(q=>{
            const ans=state.answers[q.id]?.trim();const isOpen=open===q.id;
            return (
              <div key={q.id} style={{border:`1px solid ${T.border}`,borderRadius:9,marginBottom:9,background:T.panel,overflow:"hidden"}}>
                <div onClick={()=>setOpen(isOpen?null:q.id)} style={{padding:"11px 14px",cursor:"pointer",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <div>
                    <span style={{fontSize:10,fontWeight:600,color:DIFFICULTY_COLOR[q.difficulty],padding:"1px 7px",background:DIFFICULTY_COLOR[q.difficulty]+"22",borderRadius:10,marginRight:7}}>{q.difficulty}</span>
                    <span style={{fontSize:11,color:T.sub}}>{q.num}</span>
                    <div style={{fontSize:13,color:T.text,marginTop:2}}>{q.title}</div>
                  </div>
                  <span style={{fontSize:13,color:T.sub}}>{isOpen?"▲":"▼"}</span>
                </div>
                {isOpen&&(
                  <div style={{padding:"0 14px 14px",borderTop:`1px solid ${T.border}`}}>
                    <div style={{fontSize:11,color:T.sub,margin:"10px 0 4px",fontWeight:500}}>Question:</div>
                    <div style={{fontSize:12,color:T.text,whiteSpace:"pre-wrap",lineHeight:1.7,marginBottom:10}}>{q.text}</div>
                    <div style={{fontSize:11,color:T.sub,marginBottom:4,fontWeight:500}}>Your answer:</div>
                    <div style={{background:T.bg,borderRadius:6,padding:"8px 10px",fontSize:12,color:T.text,whiteSpace:"pre-wrap",lineHeight:1.7,marginBottom:10,border:`1px solid ${T.border}`}}>{ans||"(not answered)"}</div>
                    <div style={{fontSize:11,color:T.sub,marginBottom:4,fontWeight:500}}>Model answer:</div>
                    <div style={{background:T.okBg,border:`1px solid ${T.okBorder}`,borderRadius:6,padding:"9px 11px",fontSize:12,color:T.okText,whiteSpace:"pre-wrap",lineHeight:1.7,marginBottom:8}}>{q.answer}</div>
                    <div style={{background:T.infoBg,border:`1px solid ${dark?"#1e40af":"#bfdbfe"}`,borderRadius:6,padding:"9px 11px",fontSize:12,color:T.infoText,lineHeight:1.7}}><strong>Why this matters:</strong> {q.explain}</div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}
